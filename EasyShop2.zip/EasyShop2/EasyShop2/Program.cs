using Microsoft.EntityFrameworkCore;
using EasyShop2.Data;
using EasyShop2.Models;

internal class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // ------------------------
        // Services
        // ------------------------
        builder.Services.AddControllersWithViews();

        // DbContext � SQL Server
        builder.Services.AddDbContext<ShopContext>(options =>
            options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
        );

        // Session �� role-based access
        builder.Services.AddDistributedMemoryCache();
        builder.Services.AddSession(options =>
        {
            options.IdleTimeout = TimeSpan.FromMinutes(30);
        });

        // IHttpContextAccessor � ����� �� @inject � Razor
        builder.Services.AddHttpContextAccessor();

        var app = builder.Build();

        // ------------------------
        // ��������� �� ���� � ������������ �����
        // ------------------------
        using (var scope = app.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<ShopContext>();

            db.Database.EnsureCreated(); // ������� ������ � ��������� �����������

            if (!db.Users.Any())
            {
                db.Users.Add(new User
                {
                    Username = "admin",
                    Password = "1234",
                    Role = "Admin"
                });

                db.Users.Add(new User
                {
                    Username = "user1",
                    Password = "1111",
                    Role = "User"
                });

                db.Users.Add(new User
                {
                    Username = "user2",
                    Password = "2222",
                    Role = "User"
                });

                db.Products.Add(new Product
                {
                    Name = "Mouse",
                    Price = 25,
                    ImageUrl = "/images/mouse.jpg"
                });

                db.Products.Add(new Product
                {
                    Name = "Keyboard",
                    Price = 50,
                    ImageUrl = "/images/keyboard.jpg"
                });

                db.SaveChanges();
            }
        }

        // ------------------------
        // Middleware
        // ------------------------
        app.UseStaticFiles();
        app.UseRouting();
        app.UseSession(); // ����� �� role-based ��������
        app.UseAuthorization();

        // ------------------------
        // Routing
        // ------------------------
        app.MapControllerRoute(
            name: "default",
            pattern: "{controller=Account}/{action=Login}/{id?}"
        );

        app.Run();
    }
}
